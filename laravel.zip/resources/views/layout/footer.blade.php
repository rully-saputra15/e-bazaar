<footer class="page-footer font-small blue pt-4">
    <div class="footer-copyright text-center py-3">© 2020 Copyright :
        <a target="_blank"href="https://www.instagram.com/gm.dki2/">GM DKI 2</a>
      </div>
</footer>
