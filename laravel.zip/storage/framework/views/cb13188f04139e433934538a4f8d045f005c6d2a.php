<!DOCTYPE html>
<html lang="en">


    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css2?family=Muli:wght@600;700;800&display=swap" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/bootstrap.css')); ?>">
    </head>
    <body>
            <div class="container">
                <br><br><br><br>
                <h1 style="text-align:center">Thank You!</h1>
                <p style="text-align:center">Pendaftaran Data Kamu Sukses!</p>
            </div>
    </body>
</html>
<?php /**PATH E:\Xampp\htdocs\gmdki2\resources\views/thankyou.blade.php ENDPATH**/ ?>