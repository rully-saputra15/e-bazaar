<?php $__env->startSection('content'); ?>
    <div class="container">
        <ul class="list-group">
            <a href="<?php echo e(url('addFormKategori/'. $id)); ?>"><button class="btn btn-primary float-right">Add Bazaar</button></a><br>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tmp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a style="color:black;text-decoration:none;"href="<?php echo e(url('/showTransaksi/'.$tmp['nama'])); ?>">
                <li class="list-group-item"><?php echo e($tmp['nama']); ?><br>
                <small>Buka : <b><?php echo e($tmp['buka']); ?></b></small><br>
                <small>Tutup : <b><?php echo e($tmp['tutup']); ?></b></small><br>
            </li></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\gmdki2\resources\views/kategori.blade.php ENDPATH**/ ?>