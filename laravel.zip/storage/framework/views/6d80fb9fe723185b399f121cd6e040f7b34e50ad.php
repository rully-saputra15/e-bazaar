<?php $__env->startSection('content'); ?>
<img style="width:128px;height:128px;" class="rounded mx-auto d-block"src="<?php echo e(URL::asset('img/logo.jpeg')); ?>">
<form method="post" action="<?php echo e(url('/auth')); ?>">
    <?php echo csrf_field(); ?>
    <div class="box-body">
    <div class="form-group">
        <label for="">Email</label>
        <input type="email" name="email" class="form-control" placeholder="email">
        <label for="">Password</label>
        <input type="password"name="password" class="form-control" placeholder="password">
    </div>
    <?php if(is_null($message)): ?>
    <?php else: ?>
    <span style="color:red"><?php echo e($message); ?></span><br>
    <?php endif; ?>
    <button type="submit" class="btn btn-primary">Login</button>
</div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\gmdki2\resources\views/login.blade.php ENDPATH**/ ?>