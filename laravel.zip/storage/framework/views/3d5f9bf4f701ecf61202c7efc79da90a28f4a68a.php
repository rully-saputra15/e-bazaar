<!DOCTYPE html>
<html lang="en">

    <title>E-Bazaar DKI 2</title>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css2?family=Muli:wght@600;700;800&display=swap" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="<?php echo e(URL::asset('js/jquery.mask.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/dashboard.css')); ?>">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.6.0/Chart.bundle.js" charset="utf-8"></script>
    </head>
    <body>
        <?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="container">
                <br>
                <br>
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html>
<?php /**PATH E:\Xampp\htdocs\gmdki2\resources\views/layout/master.blade.php ENDPATH**/ ?>