<?php $__env->startSection('content'); ?>
    <div class="container">

        <ul class="list-group">
            <a href="<?php echo e(url('addFormMenu')); ?>"><button class="btn btn-primary float-right">Add Menu</button></a><br>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tmp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item"><?php echo e($tmp['nama']); ?><br>
                <small>Modal : <b><?php echo e(number_format($tmp['modal'])); ?></b></small><br>
                <small>Jual : <b><?php echo e(number_format($tmp['jual'])); ?></b></small><br>
                <small>Terjual : <b><?php echo e($tmp['terjual']); ?></b></small>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\gmdki2\resources\views/menu.blade.php ENDPATH**/ ?>