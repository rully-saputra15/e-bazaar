<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="card shadow p-3 mb-5 bg-white rounded">
                    <div class="card-body">
                      <h5 class="card-title">Penghasilan Kotor : <?php echo e(number_format($total)); ?>

                    </h5>
                        <p class="card-text">Jumlah Pesanan : </p>
                        <?php for($i=0;$i<count($pesanan);$i++): ?>
                        <p class="card-text"><?php echo e($pesanan[$i][0]); ?> : <?php echo e($jumlah[$i][0]); ?> x <?php echo e($bersih[$i]); ?> = <?php echo e(number_format($jumlah[$i][0]*$bersih[$i])); ?></p>
                        <?php endfor; ?>
                        <p class="card-text"><b>Modal Tambahan</b></p>
                        <?php for($i=0;$i<count($namaModal);$i++): ?>
                            <p class="card-text"><?php echo e($namaModal[$i]); ?> : <b><?php echo e($hargaModal[$i]); ?></b></p>
                        <?php endfor; ?>
                        <p class="card-text">Penghasilan bersih : <b><?php echo e(number_format($totalBersih)); ?></b></p>
                        <a href="<?php echo e(url('/showTransaksi/'.$nama)); ?>"><button class="btn btn-warning float-right">Back</button></a>
                    </div>
                  </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\gmdki2\resources\views/detailDataTransaksi.blade.php ENDPATH**/ ?>