<?php $__env->startSection('content'); ?>
    <div class="container">

        <ul class="list-group">
            <div class="row">
                <div class="col">
                    <a href="<?php echo e(url('/addFormModal/'.$nama)); ?>"><button class="btn btn-primary float-right">Add Modal</button></a>
                </div>
            </div>
            <br>
            <div class="row">
                <div class="col">
                    <div class="card shadow p-3 mb-5 bg-white rounded">
                        <div class="card-body">
                          <h5 class="card-title">Penghasilan Kotor : <?php echo e(number_format($total)); ?>

                        </h5>
                            <a href="<?php echo e(url('/detailDataTransaksi/'.$nama)); ?>"><button class="btn btn-primary float-right">See Details</button></a>
                        </div>
                      </div>
                </div>
            </div>
            <a href="<?php echo e(url('/addFormTransaksi/'.$nama)); ?>"><button class="btn btn-primary float-right">Add Pesanan</button></a><br>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tmp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a style="color:black;text-decoration:none;" href="<?php echo e(url('/showDetailTransaksi/'.$tmp->id())); ?>">

            <?php if($tmp['status'] == 0): ?>
                <li class="list-group-item"><b><?php echo e($tmp['nama']); ?></b><br>
            <?php else: ?>
                <li class="list-group-item list-group-item-success"><b><?php echo e($tmp['nama']); ?></b><br>
            <?php endif; ?>
                <?php $__currentLoopData = $tmp['pesanan']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <small><b><?php echo e($nil['data'][0]); ?></b>: <?php echo e($nil['data'][1]); ?> x Rp <?php echo e(number_format($nil['data'][2])); ?> = Rp <?php echo e(number_format($nil['data'][1] * $nil['data'][2])); ?></small>
                    <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <small>Ongkir : <b><?php echo e(number_format($tmp['ongkir'])); ?></b></small><br>
            <small>Total : <b><?php echo e(number_format($tmp['total'])); ?></b></small><br>
            <small>Transport : <b><?php echo e($tmp['transport']); ?></b></small><br>
            <small>Alamat : <b><?php echo e($tmp['alamat']); ?></b></small><br>
            <?php if(is_null($tmp['catatan'])): ?>
            <?php else: ?>
            <small>Catatan : <b><?php echo e($tmp['catatan']); ?></b></small>
            <?php endif; ?>
            <a href="<?php echo e(url('/updateStatusTransaksi/' . $tmp->id())); ?>"><small class="float-right">
                <button class="btn btn-primary">Selesai</button>
                </small>
            </a>
            </li>
        </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\gmdki2\resources\views/transaksi.blade.php ENDPATH**/ ?>