<?php $__env->startSection('content'); ?>
    <h1>Menu</h1>
    <p>Grafik 5 Jualan DKI 2 Terlaris!(Juni 2020 - Sekarang)</p>
    <canvas id="canvas" width="200" height="200"></canvas>
    <h1>Pendapatan</h1>
    <p>Grafik 5 Jualan DKI 2 Terlaris beserta penghasilan bersih!(Juni 2020 - Sekarang)</p>
    <canvas id="canvasPendapatan" width="200" height="200"></canvas>
    <script>
         var ctx = document.getElementById("canvas").getContext('2d');
         var ctxPendapatan = document.getElementById("canvasPendapatan").getContext('2d');
         var myChart = new Chart(ctx, {
        type: 'line',
    data: {
        labels: <?php echo json_encode($nama); ?>,
        datasets: [{
            label: 'Jumlah Menu Terjual',
            data: <?php echo json_encode($terjual); ?>,
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true
                }
            }],
            xAxes:[{
                ticks:{
                    maxRotation:90,
                    minRotation:90
                }
            }]
        }
    }
    });
    var myChart = new Chart(ctxPendapatan, {
        type: 'line',
    data: {
        labels: <?php echo json_encode($nama); ?>,
        datasets: [{
            label: 'Jumlah Menu Terjual',
            data: <?php echo json_encode($pendapatan); ?>,
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true
                }
            }],
            xAxes:[{
                ticks:{
                    maxRotation:90,
                    minRotation:90
                }
            }]
        }
    }
    });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\gmdki2\resources\views/insight.blade.php ENDPATH**/ ?>