
    <nav class="navbar navbar-expand-lg">
            <a class="navbar-brand">
                <img src="<?php echo e(URL::asset('img/logo.jpeg')); ?>" width="30" height="30" class="d-inline-block align-top" alt="">
            </a>
            <ul class="navbar-nav">
                <li class="nav-item active">
                <a style="color:black;"class="nav-link" href="<?php echo e(url('/')); ?>">Home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a style="color:black;"class="nav-link" href="<?php echo e(url('/showMenu')); ?>">Menu</a>
                </li>
                <li class="nav-item">
                    <a style="color:black;" class="nav-link" href="<?php echo e(url('/login')); ?>">Login</a>
                </li>
            </ul>

        </nav>
<?php /**PATH E:\Xampp\htdocs\gmdki2\resources\views/layout/header.blade.php ENDPATH**/ ?>