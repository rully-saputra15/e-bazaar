<?php $__env->startSection('content'); ?>
    <div class="container">
    <form method="post" action="<?php echo e(url('/addMenu')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="">Nama Menu</label>
            <input type="text" class="form-control" name="nama_menu" placeholder="Nama jualan ex: kwetiaw Pak Asen"><br>
            <label for="">Harga Modal</label>
            <input id="modal"type="number" class="form-control" name="modal"><br>
            <label for="">Harga Jual</label>
            <input id="jual"type="number" class="form-control" name="jual">
        </div>
        <br>
        <p id="message" class="text-danger" style="display:none;">Harga modal lebih besar daripada jual</p>
            <button typpe="submit" class="btn btn-primary float-right">Submit</button>
        </div>
    </form>
    </div>
    <script src="<?php echo e(URL::asset('js/addMenu.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\gmdki2\resources\views/addFormMenu.blade.php ENDPATH**/ ?>