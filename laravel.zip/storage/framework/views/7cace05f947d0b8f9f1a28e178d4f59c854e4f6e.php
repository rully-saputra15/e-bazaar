<?php $__env->startSection('content'); ?>
    <div class="container">
    <form method="post" action="<?php echo e(url('/pushKategori')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="">Bulan</label>
            <input type="text" class="form-control" value="<?php echo e($id); ?>"name="id" readonly><br>
            <label for="">Nama</label>
            <input type="text" class="form-control" name="nama_bazaar" placeholder="Nama jualan ex: Bazaar Online 24 Juni"><br>
            <label for="">Buka Jualan</label>
            <input type="date" class="form-control" name="buka"><br>
            <label for="">Tutup Jualan</label>
            <input type="date" class="form-control" name="tutup">
        </div>
        <br>
            <button typpe="submit" class="btn btn-primary float-right">Submit</button>
        </div>
    </form>
    </div>
    <script src="<?php echo e(URL::asset('js/addkategori.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\gmdki2\resources\views/addKategori.blade.php ENDPATH**/ ?>